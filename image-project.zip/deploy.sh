#!/bin/bash

# 定义变量
APP_DIR="/var/www/image"
DEPLOY_DIR="$APP_DIR/public"
LOG_FILE="$APP_DIR/deploy.log"

# 创建日志文件
touch $LOG_FILE

# 记录部署时间
echo "开始部署: $(date)" >> $LOG_FILE

# 确保在正确的目录
cd $APP_DIR || exit 1
echo "切换到目录: $APP_DIR" >> $LOG_FILE

# 安装项目依赖（包括开发依赖）
echo "开始安装依赖..." >> $LOG_FILE
export PATH="$APP_DIR/node_modules/.bin:$PATH"
npm install --include=dev || {
    echo "npm install 失败" >> $LOG_FILE
    exit 1
}

# 使用本地的 webpack 进行构建
echo "开始构建项目..." >> $LOG_FILE
node_modules/.bin/webpack --mode production || {
    echo "构建失败" >> $LOG_FILE
    exit 1
}

# 确保部署目录存在
mkdir -p $DEPLOY_DIR

# 备份当前版本（如果存在）
if [ -d "$DEPLOY_DIR" ] && [ "$(ls -A $DEPLOY_DIR)" ]; then
    backup_dir="${DEPLOY_DIR}_backup_$(date +%Y%m%d_%H%M%S)"
    mv $DEPLOY_DIR $backup_dir
    echo "创建备份: $backup_dir" >> $LOG_FILE
fi

# 创建新的部署目录
mkdir -p $DEPLOY_DIR

# 复制构建文件到部署目录
echo "复制文件到部署目录..." >> $LOG_FILE
if [ -d "dist" ]; then
    cp -r dist/* $DEPLOY_DIR/ || {
        echo "文件复制失败" >> $LOG_FILE
        exit 1
    }
    echo "构建文件复制成功" >> $LOG_FILE
else
    echo "dist 目录不存在，跳过复制" >> $LOG_FILE
    exit 1
fi

# 复制必要的静态文件
cp -r public/* $DEPLOY_DIR/ 2>/dev/null || true
echo "静态文件复制完成" >> $LOG_FILE

# 设置正确的权限
echo "设置文件权限..." >> $LOG_FILE
chown -R www-data:www-data $DEPLOY_DIR
chmod -R 755 $DEPLOY_DIR

# 在文件末尾添加 Nginx 配置链接
echo "配置 Nginx..." >> $LOG_FILE
ln -sf /etc/nginx/sites-available/image /etc/nginx/sites-enabled/
nginx -t >> $LOG_FILE 2>&1 || {
    echo "Nginx 配置测试失败" >> $LOG_FILE
    exit 1
}

# 重启 nginx
echo "重启 Nginx..." >> $LOG_FILE
systemctl restart nginx || {
    echo "Nginx 重启失败" >> $LOG_FILE
    exit 1
}

echo "部署完成: $(date)" >> $LOG_FILE

# 显示部署状态
if [ $? -eq 0 ]; then
    echo "部署成功！"
    echo "请访问: http://112.124.43.20"
else
    echo "部署失败，请查看日志文件: $LOG_FILE"
fi